package com.example.podpise;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;
import  android.app.Activity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class activity_create_application extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private Spinner spinner_1,spinner_2;
    private String text_1,text_2;
    private ArrayAdapter adapter_1,adapter_2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_application);

        spinner_1 = findViewById(R.id.spinner2);
        adapter_1 = ArrayAdapter.createFromResource(this,R.array.Reference, android.R.layout.simple_spinner_dropdown_item);
        adapter_1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_1.setAdapter(adapter_1);
        spinner_1.setOnItemSelectedListener(this);

        spinner_2 = findViewById(R.id.spinner3);adapter_2 = ArrayAdapter.createFromResource(this,R.array.Uneversity, android.R.layout.simple_spinner_dropdown_item);
        adapter_2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_2.setAdapter(adapter_2);
        spinner_2.setOnItemSelectedListener(this);
       // text_1=adapter_1.getContext().toString();
      //  Toast.makeText(adapter_1.getContext(),text_1,Toast.LENGTH_SHORT).show();
        //text_2=adapter_2.getContext().toString();
        //Toast.makeText(adapter_2.getContext(),text_2,Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onStart()
    {   super.onStart();
    }
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l)
    {
        text_1=adapter_1.getItem(i).toString();
        text_2=adapter_2.getItem(i).toString();
        Toast.makeText(adapter_1.getContext(),text_1,Toast.LENGTH_SHORT).show();
        Toast.makeText(adapter_2.getContext(),text_2,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


public void send_application(View v)
{
    try {
        FileOutputStream file_output = openFileOutput("Application.txt", MODE_PRIVATE);
        file_output.write((text_1+"\n").getBytes());
        file_output.write((text_2+"\n").getBytes());
        Toast.makeText(activity_create_application.this, "Сохранено", Toast.LENGTH_SHORT).show();


    try {
        FileInputStream file_input=openFileInput("Sign.txt");
        InputStreamReader reader=new InputStreamReader(file_input);
        BufferedReader buffer=new BufferedReader(reader);
        StringBuffer str_buffer=new StringBuffer();
        String lines;

        while((lines=buffer.readLine())!=null)
        {
            str_buffer.append(lines+"\n");
            file_output.write((lines+"\n").getBytes());
        }
    }
    catch (FileNotFoundException e) {throw new RuntimeException(e);}
    catch (IOException e) {throw new RuntimeException(e);}
    }
    catch (FileNotFoundException e) {
        e.printStackTrace();
    } catch (IOException e) {
        throw new RuntimeException(e);
    }
}

}