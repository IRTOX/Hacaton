package com.example.podpise;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Environment;
import android.util.Log;
import android.view.View;


import android.os.Bundle;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    private boolean a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void Start_Create_activity(View v)
    {
        //Переход на следующию меню
        Intent intent=new Intent(this,Create_sign.class);
        startActivity(intent);
    }
    public void Start_Open_activity(View v)
    {
        Intent intent=new Intent(this,activity_open_sign.class);
        startActivity(intent);
    }

    public void Start_Create_application_activity(View v)
    {
        Intent intent=new Intent(this,activity_create_application.class);
        startActivity(intent);
    }
public void delete_key(View v)
{
    //FileOutputStream file_output = openFileOutput("Sign.txt", MODE_PRIVATE);
    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
    builder.setTitle("Удаление подписи");
            builder.setMessage("Вы точно хотите удалить подпись?");
            builder.setPositiveButton("Нет", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    Toast.makeText(MainActivity.this,"Нажата кнопка 'Нет'",Toast.LENGTH_SHORT).show();
                }
            });
            builder.setNegativeButton("Да", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    String path = Environment.getExternalStorageDirectory().toString()+"/folder";
                    Log.d("Files", "Path: " + path);
                    File directory = new File(path);
                    File[] files = directory.listFiles();
                    if(files==null)
                    {
                        deleteFile("Sign.txt");
                        Toast.makeText(MainActivity.this, "Данные удалены", Toast.LENGTH_SHORT).show();
                    }
                    else
                        Toast.makeText(MainActivity.this, "Нету подписи", Toast.LENGTH_SHORT).show();
                }
            });
    builder.create().show();
}


}